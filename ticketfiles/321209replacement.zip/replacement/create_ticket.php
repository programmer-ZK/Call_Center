<?php include_once("includes/config.php"); ?>
<?php include_once("includes/ticket_sys/config.php"); ?>
<?php
   if(!$_REQUEST['uid']){
     redirect('search_client.php');
     exit;
}
	$page_name = "create_ticket.php";
	$page_title = "Create Ticket";
	$page_level = "4";
	$page_group_id = "1";
	$page_menu_title = "Create Ticket";
?>
<?php include_once($site_root."includes/check.auth.php"); ?>
<?php
		 include_once('lib/nusoap.php');
        include_once("classes/tools.php");
        $tools = new tools();
		global $tools;
?>
<?php
		include_once("classes/admin.php");
			$admin = new admin();

?>

<?php include($site_root."includes/header.php"); ?>
<?php 
$id = $_REQUEST['uid'];
$user = ClientInfo::getUser($id);
$errors = array();
$success="";

if($_POST){
	
	
	//|| strtotime($_POST['duedate']) < strtotime(date('Y-m-d'))
  /*if ($_POST['source']==""){
       $errors['source'] = 'Source is required.';
  }elseif(!$_POST['topicId']){
      $errors['topicId'] = 'Help topic is required.';
  }elseif(strtotime($_POST['duedate']) < strtotime(date('Y-m-d'))){
      $errors['duedate'] = 'Due date should be in future.';
  }elseif(!$_POST['duedate'] ){
      $errors['duedate'] = 'Due date should be greater then current date.';
  }*/
  if($_POST['duedate']==""){
	  $_POST['duedate'] = date("Y-m-d H:i:s");
  }else{
	  $_POST['duedate'] = $_POST['duedate'].' '.$_POST['time'].':00';
	  }
  if(!$_POST['team_id']){
      $errors['team_id'] =  'Team is required.';
  }elseif(!$_POST['issue_summery']){
      $errors['issue_summery'] = 'Issue summery is required.';
  }elseif(!$_POST['message']){
      $errors['message'] = 'Issue detail is required.';
  }else{  
	   switch($_POST['a']) {
            case 'open':
			if($_POST['priority_level']){
		       $p_desc = getPriorityById($_POST['priority_level']);
	           $_POST['priority_desc'] = $p_desc->priority_desc; 
		      }
			  $_POST['source'] = 'Phone';
			  $_POST['topicId'] = '10';
	          $_POST['number']=  mt_rand(100000, 999999);
			  $_POST['poster'] = $_SESSION[$db_prefix.'_UserName'];
			  //print_r($_SESSION[$db_prefix.'_UserId']);
              $agent_id = $_SESSION[$db_prefix.'_UserId'];
              $unique_id = $admin->get_call_unique_id($agent_id);
			  $getdept = getDepartIdByTeamId($_POST['team_id']);
			  $_POST['deptId'] = $getdept->dept_id;
			  
			  if(!empty($unique_id->fields)){
				   $_POST['unique_id'] = $unique_id->fields['unique_id'];
				  }else{
				   $_POST['unique_id'] = "(NULL)";
				 }
				 $_POST['who_created'] = $agent_id;
	            $return = ClientInfo::createTicket($_POST);
			   if($return){
				   redirect('view_client.php?id='.$id.'&msg=Ticket has been created successfully');
				   //$success="Ticket has been created successfully.";
			   }
		  break;
	   }
	   
  	  /*if($id = ClientInfo::UpdateUser($_POST)){
       redirect('user-view.php?id='.$id);
    }*/
  }
}
?>

	<div class="box">
      <?php if($success!=""){?>
      <div id="message-green">
          <table border="0" width="100%" cellpadding="0" cellspacing="0">
          <tr>
          <td class="green-left"><?php echo $success;?></td>
          <td class="green-right"><a class="close-green"><img src="images/icon_close_green.gif" alt="" /></a></td>
          </tr>
          </table>
      </div>
      <?php } ?>
		<h4 class="white"><?php echo($page_title); ?> </h4>
			<form class="middle-forms cmxform" name="xForm" id="xForm" method="post"
             action="<?php  echo $_SERVER['PHP_SELF']."?uid=".$_REQUEST['uid']?>" >
            <input type="hidden" name="do" value="create">
            <input type="hidden" name="a"  value="open">
            <?php if(isset($_REQUEST['uid'])){?>
            <h4 class="white">Client Information </h4>
            <div class="box-container">
            <table  class="table-short" >
            <tbody>
            <tr><td>Client Name:</td><td>
            <div id="user-info">
                <input type="hidden" name="uid" id="uid" value="<?php echo $_REQUEST['uid'];?>" />
                <?php echo $user->name;?>
               </td></tr>
            <tr><td>Client Email:</td><td>
            <div id="user-info">
                <?php echo $user->email;?> 
            </td></tr>
                
            </tbody>
            </table>
            </div>
            <?php }else{ ?>
             <ol>
               <li class="odd">
            <?php $users = ClientInfo::getUsers(); ?>
            <label class="field-title">Client: <font color="red"> <em>*</em></font></label>
                <select name="uid">
                <option value="">&mdash; Select Client &mdash;</option>
                <?php while($usr = mysql_fetch_object($users)){ ?>
                <option value="<?php echo $usr->id;?>" <?php echo  (@$_POST['uid']==$usr->id)? "selected" :""?>>
				<?php echo $usr->name;?></option>	 
				<?php }?>          
                </select>
                </li>
              </ol>
            <?php } ?>
            <h4 class="white">Ticket Information and Options </h4>
            <div class="box-container">
            <fieldset>
            <ol>
               <?php /*?><li class="even">
				<label class="field-title">Ticket Source:</label>
                <select name="source">
                    <option value="Phone" <?php (@$_POST['source']=="Phone")? "selected":"";?>>Phone</option>
                    <option value="Email" <?php (@$_POST['source']=="Email")? "selected":"";?>>Email</option>
                    <option value="Other" <?php (@$_POST['source']=="Other")? "selected":"";?>>Other</option>
                </select>
                <br>
                <span class="error"><font color="red">&nbsp;<?php echo @$errors['source']; ?></font></span>
			     </li><?php */?>
            
           <?php /*?> <li class="odd">
				<label class="field-title">Help Topic: <font color="red"> <em>*</em></font></label>
            <?php $topics = helptopic();?>
                <select name="topicId">
                <option value="">&mdash; Select Help Topic &mdash;</option>
                <?php while($topic = mysql_fetch_object($topics)){ ?>
                <option value="<?php echo $topic->topic_id;?>" <?php echo  (@$_POST['topicId']==$topic->topic_id)? "selected" :""?>><?php echo $topic->topic;?></option>
				<?php }?>       
                </select>
                <br>
                <span class="error"><font color="red">&nbsp;<?php echo @$errors['topicId']; ?></font></span>
            </li><?php */?>
           <?php /*?> <li class="even">
              <label class="field-title">Department:<font color="red"> <em>*</em></font></label>
             <?php $deptts = getDept();?>
                <select name="deptId">
                 
                  <option value="">&mdash; Select Department&mdash;</option>
                   <?php while($deptt = mysql_fetch_object($deptts)){?>
                <option value="<?php echo $deptt->dept_id;?>" <?php echo  (@$_POST['deptId']==$deptt->dept_id)? "selected" :""?>><?php echo $deptt->dept_name;?></option>
				<?php }?>
                    </select>
                <br>
                <span class="error"><font color="red">&nbsp;<?php echo @$errors['deptId']; ?></font></span>
            </li>
            <?php */?>
             <li class="even">
              <label class="field-title">Team/Group:<font color="red"> <em>*</em></font></label>
             <?php $teams = getTeam();?>
                <select name="team_id">
                 
                  <option value="">&mdash; Select Team&mdash;</option>
                   <?php while($team = mysql_fetch_object($teams)){?>
                <option value="<?php echo $team->team_id;?>" <?php echo  (@$_POST['team_id']==$team->team_id)? "selected" :""?>><?php echo $team->name;?></option>
				<?php }?>
                    </select>
                <br>
                <span class="error"><font color="red">&nbsp;<?php echo @$errors['team_id']; ?></font></span>
            </li>
            <li class="odd">
                <label class="field-title">Due Date:</label>
                <input id="fdate" name="duedate" value="<?php echo @$_POST['duedate'];?>" size="12"  
                class="txtbox-short-date" autocomplete="off" readonly="readonly" 
                onclick="javascript:NewCssCal ('fdate','yyyyMMdd', 'dropdown')">
                &nbsp;&nbsp;
                <select name="time" id="time">
                <option value="" selected>Time</option>
                <option value="23:45" >11:45 PM</option>
                <option value="23:30" >11:30 PM</option>
                <option value="23:15" >11:15 PM</option>
                <option value="23:00" >11:00 PM</option>
                <option value="22:45" >10:45 PM</option>
                <option value="22:30" >10:30 PM</option>
                <option value="22:15" >10:15 PM</option>
                <option value="22:00" >10:00 PM</option>
                <option value="21:45" >09:45 PM</option>
                <option value="21:30" >09:30 PM</option>
                <option value="21:15" >09:15 PM</option>
                <option value="21:00" >09:00 PM</option>
                <option value="20:45" >08:45 PM</option>
                <option value="20:30" >08:30 PM</option>
                <option value="20:15" >08:15 PM</option>
                <option value="20:00" >08:00 PM</option>
                <option value="19:45" >07:45 PM</option>
                <option value="19:30" >07:30 PM</option>
                <option value="19:15" >07:15 PM</option>
                <option value="19:00" >07:00 PM</option>
                <option value="18:45" >06:45 PM</option>
                <option value="18:30" >06:30 PM</option>
                <option value="18:15" >06:15 PM</option>
                <option value="18:00" >06:00 PM</option>
                <option value="17:45" >05:45 PM</option>
                <option value="17:30" >05:30 PM</option>
                <option value="17:15" >05:15 PM</option>
                <option value="17:00" >05:00 PM</option>
                <option value="16:45" >04:45 PM</option>
                <option value="16:30" >04:30 PM</option>
                <option value="16:15" >04:15 PM</option>
                <option value="16:00" >04:00 PM</option>
                <option value="15:45" >03:45 PM</option>
                <option value="15:30" >03:30 PM</option>
                <option value="15:15" >03:15 PM</option>
                <option value="15:00" >03:00 PM</option>
                <option value="14:45" >02:45 PM</option>
                <option value="14:30" >02:30 PM</option>
                <option value="14:15" >02:15 PM</option>
                <option value="14:00" >02:00 PM</option>
                <option value="13:45" >01:45 PM</option>
                <option value="13:30" >01:30 PM</option>
                <option value="13:15" >01:15 PM</option>
                <option value="13:00" >01:00 PM</option>
                <option value="12:45" >12:45 PM</option>
                <option value="12:30" >12:30 PM</option>
                <option value="12:15" >12:15 PM</option>
                <option value="12:00" >12:00 PM</option>
                <option value="11:45" >11:45 AM</option>
                <option value="11:30" >11:30 AM</option>
                <option value="11:15" >11:15 AM</option>
                <option value="11:00" >11:00 AM</option>
                <option value="10:45" >10:45 AM</option>
                <option value="10:30" >10:30 AM</option>
                <option value="10:15" >10:15 AM</option>
                <option value="10:00" >10:00 AM</option>
                <option value="09:45" >09:45 AM</option>
                <option value="09:30" >09:30 AM</option>
                <option value="09:15" >09:15 AM</option>
                <option value="09:00" >09:00 AM</option>
                <option value="08:45" >08:45 AM</option>
                <option value="08:30" >08:30 AM</option>
                <option value="08:15" >08:15 AM</option>
                <option value="08:00" >08:00 AM</option>
                <option value="07:45" >07:45 AM</option>
                <option value="07:30" >07:30 AM</option>
                <option value="07:15" >07:15 AM</option>
                <option value="07:00" >07:00 AM</option>
                <option value="06:45" >06:45 AM</option>
                <option value="06:30" >06:30 AM</option>
                <option value="06:15" >06:15 AM</option>
                <option value="06:00" >06:00 AM</option>
                <option value="05:45" >05:45 AM</option>
                <option value="05:30" >05:30 AM</option>
                <option value="05:15" >05:15 AM</option>
                <option value="05:00" >05:00 AM</option>
                <option value="04:45" >04:45 AM</option>
                <option value="04:30" >04:30 AM</option>
                <option value="04:15" >04:15 AM</option>
                <option value="04:00" >04:00 AM</option>
                <option value="03:45" >03:45 AM</option>
                <option value="03:30" >03:30 AM</option>
                <option value="03:15" >03:15 AM</option>
                <option value="03:00" >03:00 AM</option>
                <option value="02:45" >02:45 AM</option>
                <option value="02:30" >02:30 AM</option>
                <option value="02:15" >02:15 AM</option>
                <option value="02:00" >02:00 AM</option>
                <option value="01:45" >01:45 AM</option>
                <option value="01:30" >01:30 AM</option>
                <option value="01:15" >01:15 AM</option>
                <option value="01:00" >01:00 AM</option>
                <option value="00:45" >12:45 AM</option>
                <option value="00:30" >12:30 AM</option>
                <option value="00:15" >12:15 AM</option>
                <option value="00:00" selected="selected">12:00 AM</option>
                </select> 
               <?php /*?> <br>
                <span class="error"><font color="red">&nbsp;<?php echo @$errors['duedate']; ?></font></span><?php */?>
                
           </li>
           </ol>
           </fieldset>
            </div>
            <h4 class="white"><em><strong>Ticket Details</strong>:
        Please Describe Your Issue</em> </h4>
            <div class="box-container">
            <fieldset>
            <ol>
               <li class="even">
				<label class="field-title">Issue Summary:<font color="red"> <em>*</em></font></label>
                <input type="text" id="issue_summery" size="40" maxlength="50" placeholder="" name="issue_summery"
            value="<?php echo @$_POST['issue_summery'];?>"/>
                <br>
                <span class="error"><font color="red">&nbsp;<?php echo @$errors['issue_summery']; ?></font></span>
			  </li>
               <li class="odd">
				<label class="field-title"><strong>Issue Details:</strong><font color="red"> <em>*</em></font></label>
                <textarea style="width:100%;" name="message"
                placeholder="Details on the reason(s) for opening the ticket."cols="21" rows="8" 
            style="width:80%;"><?php echo @$_POST['message'];?></textarea>
              <br>
              <span class="error"><font color="red">&nbsp;<?php echo @$errors['message']; ?></font></span>
			  </li>
              <li class="even">
               <?php $priorities = getPriority();?>
				<label class="field-title"><strong> Priority Level:</strong></label>
                <select name="priority_level" id="priority_level" data-prompt="Select">
                        <option value="">&mdash; Select &mdash;</option>
                         <?php while($priority = mysql_fetch_object($priorities)){?>
                          <option value="<?php echo $priority->priority_id;?>" <?php echo (@$_POST['priority_level']==$priority->priority_id)? "selected" :""?>>
						   <?php echo $priority->priority_desc;?></option>
				<?php }?>
                           
                    </select>
			  </li>
              <li class="odd">
				<label class="field-title"><strong> Internal Note:</strong></label>
                <textarea class="richtext ifhtml draft draft-delete"
                 placeholder="Optional internal note (recommended on assignment)." 
                 name="note" cols="21" rows="6" style="width:100%;"><?php echo @$_POST['note'];?></textarea>
			  </li>
           </ol>
            <p class="align-right">
						<a id="btn_submit" class="button" href="javascript:document.xForm.submit();" 
                        onclick="javascript:document.xForm.submit();"><span>Submit</span></a>
						<!--<input type="hidden" value="Submit" name="new_customer" id="new_customer" />-->
					</p>
           </fieldset>
            </div>	
			</form>
 		
    </div>
<?php include($site_root."includes/footer.php"); ?>

 