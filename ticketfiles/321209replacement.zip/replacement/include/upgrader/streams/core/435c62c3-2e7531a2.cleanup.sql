ALTER TABLE `%TABLE_PREFIX%groups` DROP `dept_access`;
