<?php
header('Location: ../');
?>
